public class Author {
    String Name;
    String Description;

    public Author(String Name, String Description){
        this.Name = Name;
        this.Description = Description;
    }
}
