public class Book {
    Author author;
    String title;
    String ISBN;
    Borrower borrower;
    Boolean isBorrowed;

    public Book(String title , String ISBN, Author author){
        this.title = title;
        this.ISBN = ISBN;
        this.author = author;
    }
}
