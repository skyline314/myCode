
import java.util.ArrayList;
import java.util.List;

public class Borrower {
    String Name;
    List<Book> myBooks = new ArrayList<Book>();


    public Borrower(String name) {
        this.Name = name;
    }

    public void displayBorrowedBooks(){
        System.out.println(Name + " borrow :");
        int j = 1;
        for(Book book : myBooks){
            System.out.println(j + ". " + book.title);
        }
    }

}
