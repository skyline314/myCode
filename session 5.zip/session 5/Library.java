
import java.util.ArrayList;
import java.util.List;

public class Library {
    public List<Book> books = new ArrayList<Book>();

    public void addBook(Book book){
        books.add(book);
    }

    public void borrowBook(Borrower borrower , Book book){
        book.borrower = borrower;
        borrower.myBooks.add(book);
        book.isBorrowed = true;
    }

    public void returnBook(Borrower borrower , Book book){
        borrower.myBooks.remove(book);
        book.borrower = null;
        book.isBorrowed = false;
    }

    public void displayLibraryBooks(){
        System.out.println("Available Book : ");
        int i = 1;
        for(Book book : books){
            if(book.isBorrowed == false){
                System.out.println(i + ". " + book.title);
                i++;
            }
        }
    }
}
